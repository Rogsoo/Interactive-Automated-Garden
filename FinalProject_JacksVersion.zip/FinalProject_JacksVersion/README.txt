WELCOME TO NAVIDLAND - YOUR OWN PERSONAL AUTOMATED GARDEN:)

**Please read thoroughly before playing



To Begin:
    Enter full screen mode
    Click "Press to Play" --> top left menu

Plant your garden:
    Select the type of plant you'd like to input: Flower, Herb, Vegetable, or Cactus --> top left menu

    Click on any plot in the garden --> lower-half grid
        Nothing will happen

    To plant, select the plot in the garden that you wish you put your plant, it will automatically populate

        Be careful!!! Once you plant your seeds you cannot dig them up again.

    Feel free to change the type of plant as you go!

Play game:
    Click "Start"
    One day = 5 seconds
    Day will automatically increment
Exit the garden:
    Click "Finish"

How the garden works:
- For Flowers: Bees must pollinate them at least once every 3 days
    - If a bee has not pollinated it, the flower will die

- For Herbs, Vegetables and Cacti: A pest may spawn on it
    - Pest Control hasan 75% chance of killing the pest
    - If Pest Control fails, the Pest will kill the Plant


-Every two days, the plants get watered
-Every three days, the plants get heated
-The day is displayed at the top left of the screen
-The weather changes randomly every day
