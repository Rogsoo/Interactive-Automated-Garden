package com.example.finalproject_jacksversion;

import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;


public class PestControl {
    //Pest control searches for bugs in every cell.
    // The system has a 50% success rate
    public static final Map<Insect, ImageView> insectViewMap = new HashMap<>();


}
